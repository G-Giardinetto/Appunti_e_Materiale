package giardinettogiuseppe_webserviceclient;

import pkg.EventoMusicale;
import pkg.EventoMusicaleBean;
import pkg.EventoMusicaleBeanService;

public class WebServiceClient {

    public static void main(String[] args) {
        EventoMusicaleBeanService service = new EventoMusicaleBeanService();

                        EventoMusicaleBean port = service.getEventoMusicaleBeanPort();

                        EventoMusicale evento = port.trovaTitolo("festa di Natale 2023");

                        evento.setStruttura("Palapartenope");

                        evento.setCategoria("ROCK");

                        port.modificaEventoMusicale(evento); //Fix sintassi nome metodo ( modificaEvento() -> modificaEventoMusicale() )
    }
    
}
