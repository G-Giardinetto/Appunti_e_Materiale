package messageclient;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import pkg.MessageWrapper;

public class MessageClient {

    public static void main(String[] args) throws NamingException{

           Context ctx = new InitialContext();

           ConnectionFactory cf = (ConnectionFactory)

                                                                     ctx.lookup("jms/javaee7/ConnectionFactory");

           Destination topic = (Destination) ctx.lookup("jms/javaee7/Topic");

           try(JMSContext jmsContext = cf.createContext()){
               MessageWrapper msg= new MessageWrapper("festa di Natale 2024", "Quest'anno la festa di Natale si terrà da Giggetto. Vi aspettiamo numerosi!", "25/12/2024", "14:00", "Giggetto", 30.0f, "JAZZ"); //Fix sintassi (30.0 -> 30.0f)

                jmsContext.createProducer().send(topic,msg);

                System.out.println("Messaggio inviato:"+msg);

          } catch(Exception e){

                e.printStackTrace();

                }

    }    
}
