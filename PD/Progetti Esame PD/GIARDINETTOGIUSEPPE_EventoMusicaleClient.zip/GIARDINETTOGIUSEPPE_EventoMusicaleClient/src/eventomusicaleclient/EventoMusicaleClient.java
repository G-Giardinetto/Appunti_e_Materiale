package eventomusicaleclient;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import pkg.RemoteBean;

public class EventoMusicaleClient {

    public static void main(String[] args) throws NamingException { //Aggiunta throws NamingException
        Context ctx = new InitialContext(); 
               RemoteBean bean = (RemoteBean) ctx.lookup("java:global/GIARDINETTOGIUSEPPE_SERVER/EventoMusicaleBean!pkg.RemoteBean"); //Aggiunta stringa di lookup e aggiunto cast a RemoteBean
               String data="25/12/2023";
               String categoria="JAZZ";
               String struttura="Giggetto";
               System.out.println("Tutti gli eventi:"+bean.trovaTutto());
               System.out.println("Tutti gli eventi "+categoria+":\n"+

                                                                                      bean.trovaCategoria(categoria));

               System.out.println("Tutti gli eventi a"+struttura+":\n"+

                                                                                         bean.trovaStruttura(struttura));

               System.out.println("Tutti gli eventi a"+struttura +"in data"+data+":\n"+

                                                                               bean.trovaStrutturaEData(struttura,data));
    }
    
}
