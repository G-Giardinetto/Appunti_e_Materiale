package pkg;

import java.util.List;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

public class EventHandler{

       @Inject 

       private EventoMusicaleBean bean;

       public void handleEvent(@Observes @eventoAggiunto EventoMusicale e){
                //Fix sintassi nome classe (Lista -> List)
              List<EventoMusicale> listaEventiPerStruttura =                                                                                                                               bean.trovaStruttura(e.getStruttura());

              if(listaEventiPerStruttura.size()!=1){

                            System.out.println("INFO:Eventi Multipli\n"+e+"\n---------------\n");

                            System.out.println("LISTA EVENTI CON LA STESSA STRUTTURA");

                           for(EventoMusicale ev : listaEventiPerStruttura){

                                          System.out.println(ev);

                            }

              }



       }

}
