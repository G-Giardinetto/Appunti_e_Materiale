package pkg;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@NamedQueries({
    @NamedQuery(name = "findById", query = "SELECT e FROM EventoMusicale e WHERE e.id=:id"),
    @NamedQuery(name = "findByData", query = "SELECT e FROM EventoMusicale e WHERE e.data=:data"),
    @NamedQuery(name = "findByCategoria", query = "SELECT e FROM EventoMusicale e WHERE e.categoria=:categoria"),
    @NamedQuery(name = "findAll", query = "SELECT e FROM EventoMusicale e"),
    @NamedQuery(name = "findByStruttura", query = "SELECT e FROM EventoMusicale e WHERE e.struttura=:struttura"),
    @NamedQuery(name = "findByStrutturaANDdata", query = "SELECT e FROM EventoMusicale e WHERE (e.struttura=:struttura)AND(e.data=:data)"),
    @NamedQuery(name = "findByTitolo", query = "SELECT e FROM EventoMusicale e WHERE e.titolo=:titolo"),})
@XmlRootElement
public class EventoMusicale implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    @Column(unique = true)  //Aggiunto il constrain unique
    private String titolo;
    private String descrizione;
    private String data;
    private String orario;
    private String struttura;
    private float costo;
    private String categoria;

    public EventoMusicale() {
    }

    public EventoMusicale(String titolo, String desc, String data, String orario, String struttura, float costo, String categoria) {
        this.titolo = titolo;
        this.descrizione = desc;
        this.data = data;
        this.orario = orario;
        this.struttura = struttura;
        this.costo = costo;
        this.categoria = categoria;
    }

    public int getId() { //Aggiunti getter,setter e toString
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getOrario() {
        return orario;
    }

    public void setOrario(String orario) {
        this.orario = orario;
    }

    public String getStruttura() {
        return struttura;
    }

    public void setStruttura(String struttura) {
        this.struttura = struttura;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "EventoMusicale{" + "id=" + id + ", titolo=" + titolo + ", descrizione=" + descrizione + ", data=" + data + ", orario=" + orario + ", struttura=" + struttura + ", costo=" + costo + ", categoria=" + categoria + '}';
    }
    
}
