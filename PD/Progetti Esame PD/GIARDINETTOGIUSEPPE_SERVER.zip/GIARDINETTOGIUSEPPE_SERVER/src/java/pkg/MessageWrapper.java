package pkg;

import java.io.Serializable;


public class MessageWrapper implements Serializable{

            private String titolo;

            private String descrizione;

            private String data;
            private String orario;
            private String struttura;
            private float costo;
            private String categoria;

            public MessageWrapper(){}

            public MessageWrapper(String titolo, String desc, String data, String orario,                                                                   String struttura, float costo, String categoria){

             this.titolo=titolo;
             this.descrizione=desc;
             this.data=data;
             this.orario=orario;
             this.struttura=struttura;
             this.costo=costo;
             this.categoria=categoria;

          }
//Aggiunti getter,setter e toString
    public String getTitle() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getOrario() {
        return orario;
    }

    public void setOrario(String orario) {
        this.orario = orario;
    }

    public String getStruttura() {
        return struttura;
    }

    public void setStruttura(String struttura) {
        this.struttura = struttura;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "MessageWrapper{" + "titolo=" + titolo + ", descrizione=" + descrizione + ", data=" + data + ", orario=" + orario + ", struttura=" + struttura + ", costo=" + costo + ", categoria=" + categoria + '}';
    }
            
}
