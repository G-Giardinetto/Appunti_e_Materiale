package pkg;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@InterceptThis
public class InterceptEventiMusicali{
         Integer daGiggetto=0;
         Integer nonDaGiggetto=0;

        @AroundInvoke
         private Object intereptEvento(InvocationContext ic) throws Exception{ //aggiunta throws Exception

                 String methodName=ic.getMethod().getName();

                 if(methodName.equals("trovaStruttura") || methodName.equals("trovaStrutturaEData")){ //Fix sintassi (aggiunta parentesi tonda)

                                  Object[] obj = ic.getParameters();

                                  String struttura= (String) obj[0 ];

                                  if(struttura.equalsIgnoreCase("giggetto")){ //Fix sintassi (aggiunta parentesi tonda)

                                           System.out.println("Tutti da giggetto!");

                                           daGiggetto+=1;

                                   } else { 

                                          nonDaGiggetto+=1;

                                   }  if(daGiggetto-nonDaGiggetto == 20 || //Fix sintassi operatore == (= -> ==)

                                          daGiggetto-nonDaGiggetto == -20) //Fix sintassi operatore == (= -> ==)

                                            System.out.println("Forza andiamo anche da giggietto!");

                  } 

          return ic.proceed();

          }

}


