package pkg;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
        className = "org.apache.derby.jdbc.EmbeddedDataSource",
        name = "jdbc/EsameDS",
        databaseName = "EsameDB"
)

public class DBPopulator {

    @Inject
    private EventoMusicaleBean bean;

    EventoMusicale e;

    @PostConstruct

    private void populate() {
        e = new EventoMusicale("festa di Natale 2023", "Quest'anno la festa di Natale si terrà da Giggetto. Vi aspettiamo numerosi!", "25/12/2023", "14:00", "Giggetto", 30.0f, "JAZZ"); //Fix sintassi 30.0 -> 30.0f
        bean.aggiungiEventoMusicale(e); //rimossa assegnazione
    }

    @PreDestroy

    private void clear() {
        e=bean.modificaEventoMusicale(e); //aggiunta metodo e assegnazione
        bean.rimuoviEventoMusicale(e);

    }

}
