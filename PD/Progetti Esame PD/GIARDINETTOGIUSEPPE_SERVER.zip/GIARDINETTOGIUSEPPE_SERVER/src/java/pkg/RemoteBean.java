package pkg;

import java.util.List;
import javax.ejb.Remote;
import javax.jws.WebService;

@Remote
@WebService
public interface RemoteBean{

    public void aggiungiEventoMusicale(EventoMusicale e); //Cambiato il tipo di ritorno in void
    public void rimuoviEventoMusicale(EventoMusicale e);
    public EventoMusicale modificaEventoMusicale(EventoMusicale e);
    public EventoMusicale trovaId(int id);
    public List<EventoMusicale> trovaData(String data);
    public List<EventoMusicale> trovaCategoria(String categoria);
    public List<EventoMusicale> trovaTutto();
    public List<EventoMusicale> trovaStruttura(String struttura);
    public List<EventoMusicale> trovaStrutturaEData(String struttura, String Data);
    public EventoMusicale trovaTitolo(String titolo);

}
