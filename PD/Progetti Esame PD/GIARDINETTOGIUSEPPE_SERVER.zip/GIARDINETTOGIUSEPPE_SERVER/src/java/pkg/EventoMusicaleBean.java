package pkg;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateless

@LocalBean

@WebService

public class EventoMusicaleBean implements RemoteBean {

    @Inject
    private EntityManager em;

    @Override
//cambiato il tipo di ritorno del metodo aggiungiEventoMusicale con void
    public void aggiungiEventoMusicale(EventoMusicale e) { 
        em.persist(e); //Rimosso return
               

    }

    @Override
    public void rimuoviEventoMusicale(EventoMusicale e) {

        em.remove(e);

    }

    @Override
    public EventoMusicale modificaEventoMusicale(EventoMusicale e) {
        return em.merge(e);

    }

    @Override

    public EventoMusicale trovaId(int id) {
        TypedQuery query = em.createNamedQuery("findById", EventoMusicale.class);

        query.setParameter("id", id);

        return (EventoMusicale) query.getSingleResult();

    }

    @Override
    public List<EventoMusicale> trovaData(String data) {

        TypedQuery query = em.createNamedQuery("findByData", EventoMusicale.class);

        query.setParameter("data", data);

        return query.getResultList();

    }

    @Override

    public List<EventoMusicale> trovaCategoria(String categoria) {
        TypedQuery query = em.createNamedQuery("findByCategoria", EventoMusicale.class);

        query.setParameter("categoria", categoria);

        return query.getResultList();

    }

    @Override
    public List<EventoMusicale> trovaTutto() {
        TypedQuery query = em.createNamedQuery("findAll", EventoMusicale.class);

        return query.getResultList();

    }

    @InterceptThis

    @Override

    public List<EventoMusicale> trovaStruttura(String struttura) {

        TypedQuery query = em.createNamedQuery("findByStruttura", EventoMusicale.class);

        query.setParameter("struttura", struttura);

        return query.getResultList();

    }

    @InterceptThis

    @Override

    public List<EventoMusicale> trovaStrutturaEData(String struttura, String data) { //fix sintassi oggetto data (Data -> data)

        TypedQuery query = em.createNamedQuery("findByStrutturaANDdata", EventoMusicale.class);

        query.setParameter("struttura", struttura);

        query.setParameter("data", data);

        return query.getResultList();

    }

    @Override

    public EventoMusicale trovaTitolo(String titolo) {
        TypedQuery query = em.createNamedQuery("findByTitolo", EventoMusicale.class);

        query.setParameter("titolo", titolo);

        return (EventoMusicale) query.getSingleResult();

    }

}
