package pkg;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName="jms/javaee7/Topic")

public class MDB implements MessageListener{

       @Inject 

       private EventoMusicaleBean bean;

       @Inject
       @eventoAggiunto
       Event<EventoMusicale> eventoAgg;

       @Override //Aggiunto Override
       public void onMessage(Message message){

           try { //Aggiunto try-catch attorno al blocco
               MessageWrapper msg = message.getBody(MessageWrapper.class); //Aggiunto MessageWrapper.class come parametro del metodo
               EventoMusicale evento = new EventoMusicale(msg.getTitle(),msg.getDescrizione(),msg.getData(),
                       msg.getOrario(),msg.getStruttura(),msg.getCosto(),msg.getCategoria());
                       System.out.println("Messaggio in entrata: "+msg);//Aggiunta stampa messaggio arrivato
                       bean.aggiungiEventoMusicale(evento);
                       
                       eventoAgg.fire(evento);
           } catch (JMSException ex) {
               Logger.getLogger(MDB.class.getName()).log(Level.SEVERE, null, ex);
           }

       }

}
