
public class Articolo {
	String nome;
	int quantità;
	double costo_prestito;
	int id;
	String editore;
	String tipologia;
	String autore;
	public Articolo(String editore, int id, String autore) {
		this.autore=autore;
		this.id=id;
		this.costo_prestito=10;
		this.editore=editore;
		this.quantità=1;
	}
	public Articolo() {}
	public void add_item() {
		this.quantità++;
	}
	public void togliArticolo() {
		if(this.quantità!=0) {
			quantità--;
			System.out.println("\narticolo rimosso\n");
		}
		else System.out.println("articolo inesistente");
	}
	@Override
	public String toString() {
		return this.id+" "+this.autore+" "+this.editore+" "+this.tipologia+" "+this.costo_prestito+"euro "+this.quantità;
	}
}