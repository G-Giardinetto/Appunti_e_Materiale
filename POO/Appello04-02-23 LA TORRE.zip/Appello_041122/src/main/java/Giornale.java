
public class Giornale extends Articolo {
	public Giornale() {
	super();
	}
	public Giornale(String editore, int id, String curatore) {
		super(editore,id,curatore);
		this.costo_prestito=3;
	}
	public void set_tipologia(String tipologia) {
			tipologia=tipologia.toUpperCase();
			if(tipologia.compareTo("SPORTIVO")==0 
					|| tipologia.compareTo("ECONOMICO")==0 
					|| tipologia.compareTo("GOSSIP")==0
					|| tipologia.compareTo("ALLNEWS")==0)
				this.tipologia=tipologia;
	}
}
