
public class Libro extends Articolo{
	public Libro() {
		super();
	}
	public Libro(String editore, int id, String autore) {
	super(editore, id, autore);
	this.costo_prestito=10;
}
	public void set_tipologia(String tipologia) {
		if(tipologia.compareTo("Scolastico")==0 
				|| tipologia.compareTo("Narrativa")==0 
				|| tipologia.compareTo("Professionale")==0
				|| tipologia.compareTo("Svago")==0)
			this.tipologia=tipologia;
	}
}
