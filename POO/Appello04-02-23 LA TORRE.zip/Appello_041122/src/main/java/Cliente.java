import java.util.ArrayList;
public class Cliente {
	String nome,cognome,cf,indirizzo,comune_di_residenza;
	int cell_number;
	ArrayList<Articolo> libri_presi=new ArrayList<>();
	public Cliente() {
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public void setCell_number(int cell_number) {
		this.cell_number = cell_number;
	}
	public void setComune_di_residenza(String comune_di_residenza) {
		this.comune_di_residenza = comune_di_residenza;
	}
	public void setCf(String cf) {
		this.cf = cf;
	}
	@Override 
	public String toString(){
		return this.nome+" "+this.cognome+" "+this.cf+" "+this.cell_number+" "+this.indirizzo+" "+this.comune_di_residenza;
	}
}
