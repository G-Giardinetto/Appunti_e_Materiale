
public class Rivista extends Articolo {
	public Rivista() {
	super();
	}
	public Rivista(String editore, int id, String autore) {
		super(editore,id,autore);
		this.costo_prestito=5;
	}
	public void set_tipologia(String tipologia) {
			tipologia=tipologia.toUpperCase();
			if(tipologia.compareTo("SETTIMANALE")==0 
					|| tipologia.compareTo("MENSILE")==0 
					|| tipologia.compareTo("BIMESTRALE")==0
					|| tipologia.compareTo("TRIMESTRALE")==0)
				this.tipologia=tipologia;
	}
}
