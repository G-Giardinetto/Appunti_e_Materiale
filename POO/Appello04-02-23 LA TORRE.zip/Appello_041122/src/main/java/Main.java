import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {

	public static void main(String[] args) throws IOException{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		HashMap<String, ArrayList<Articolo>> magazzino=new HashMap<>();
		ArrayList<Articolo> libri = new ArrayList<>();
		ArrayList<Articolo> giornali= new ArrayList<>();
		ArrayList<Articolo> riviste = new ArrayList<>();
		magazzino.put("libro", libri);
		magazzino.put("rivista", riviste);
		magazzino.put("giornale", giornali);
		while(true) {
		System.out.println("Menù:\n1- inserisci un nuovo articolo\n2- visualizza magazzino\n3- prendi in prestito un articolo");
		switch(Integer.parseInt(br.readLine())) {
		case 1:
			System.out.println("\n- Libro\n- Rivista\n- Giornale\npoi inserire editore, id, autore/curatore");
			String scelta=br.readLine();
			if(scelta.toLowerCase().compareTo("libro")==0 
					|| scelta.toLowerCase().compareTo("rivista")==0 
					|| scelta.toLowerCase().compareTo("giornale")==0) {
				
				if(scelta.toLowerCase().compareTo("libro")==0) {
					magazzino.get(scelta).add(new Libro(br.readLine(),Integer.parseInt(br.readLine()),br.readLine()));
				}
				if(scelta.toLowerCase().compareTo("rivista")==0)
					magazzino.get(scelta).add(new Rivista(br.readLine(),Integer.parseInt(br.readLine()),br.readLine()));
				if(scelta.toLowerCase().compareTo("giornale")==0)
				magazzino.get(scelta).add( new Giornale(br.readLine(),Integer.parseInt(br.readLine()),br.readLine()));
			}
		break;
		case 2:
			magazzino.toString();
			break;
		case 3:
			System.out.println("inserire id articolo");
			int id=Integer.parseInt(br.readLine());
			//magazzino.entrySet().contains();
		}
		}
	}
	}
